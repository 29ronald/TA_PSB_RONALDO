package id.rafeyosa.dicoding.fategrandorder

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions

class AboutActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)
        val actionbar = supportActionBar
        actionbar!!.title = "About"
        actionbar.setDisplayHomeAsUpEnabled(true)

        val imgvPhoto1: ImageView = findViewById(R.id.imgv_photo_1)
        val imgvPhoto2: ImageView = findViewById(R.id.imgv_photo_2)

        Glide.with(this)
            .load("https://portal.unp.ac.id/images/user_foto/18076027.jpg")
            .apply(RequestOptions())
            .into(imgvPhoto1)

        Glide.with(this)
            .load("https://portal.unp.ac.id/images/user_foto/18076009.jpg")
            .apply(RequestOptions())
            .into(imgvPhoto2)
    }
    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
