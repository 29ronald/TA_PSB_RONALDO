package id.rafeyosa.dicoding.fategrandorder

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Html
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions

class DetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        val actionbar = supportActionBar
        actionbar!!.title = "Detail "+intent.getStringExtra(EXTRA_NAME)
        actionbar.setDisplayHomeAsUpEnabled(true)

        val imgv1: ImageView = findViewById(R.id.imageView1)
        val imgv2: ImageView = findViewById(R.id.imageView2)
        val imgv3: ImageView = findViewById(R.id.imageView3)
        val imgv4: ImageView = findViewById(R.id.imageView4)

        val tvNameServant: TextView = findViewById(R.id.tv_nameServant)
        val tvDetailServant: TextView = findViewById(R.id.tv_detailServant)
        val imgvLogoServant: ImageView = findViewById(R.id.imgv_logoServant)

        val tvDetail1: TextView = findViewById(R.id.tv_detail1)
        val tvDetail2: TextView = findViewById(R.id.tv_detail2)
        val tvDetail3: TextView = findViewById(R.id.tv_detail3)
        val tvDetail4: TextView = findViewById(R.id.tv_detail4)

        val tvNameHeroes1: TextView = findViewById(R.id.tv_nameHeroes1)
        val tvNameHeroes2: TextView = findViewById(R.id.tv_nameHeroes2)
        val tvNameHeroes3: TextView = findViewById(R.id.tv_nameHeroes3)

        val imgvPhotoHeroes1: ImageView = findViewById(R.id.imgv_photoHeroes1)
        val imgvPhotoHeroes2: ImageView = findViewById(R.id.imgv_photoHeroes2)
        val imgvPhotoHeroes3: ImageView = findViewById(R.id.imgv_photoHeroes3)

        Glide.with(this).load("https://vignette.wikia.nocookie.net/fategrandorder/images/f/f5/Powerup.png/revision/latest/scale-to-width-down/25?cb=20180105152628")
            .apply(RequestOptions()).into(imgv1)
        Glide.with(this).load("https://vignette.wikia.nocookie.net/fategrandorder/images/f/f4/Stargainup.png/revision/latest/scale-to-width-down/25?cb=20180105152937")
            .apply(RequestOptions()).into(imgv2)
        Glide.with(this).load("https://vignette.wikia.nocookie.net/fategrandorder/images/6/62/Critabsup.png/revision/latest/scale-to-width-down/25?cb=20180105151747")
            .apply(RequestOptions()).into(imgv3)
        Glide.with(this).load("https://vignette.wikia.nocookie.net/fategrandorder/images/f/fe/Instapowerup.png/revision/latest/scale-to-width-down/25?cb=20180105152239")
            .apply(RequestOptions()).into(imgv4)

        val nameServant = intent.getStringExtra(EXTRA_NAME)
        tvNameServant.text = Html.fromHtml("<u>$nameServant</u>")
        tvDetailServant.text = intent.getStringExtra(EXTRA_DETAIL)

        Glide.with(this)
            .load(intent.getStringExtra(EXTRA_PHOTO))
            .apply(RequestOptions())
            .into(imgvLogoServant)

        tvDetail1.text = intent.getStringExtra(EXTRA_DETAIL1)
        tvDetail2.text = intent.getStringExtra(EXTRA_DETAIL2)
        tvDetail3.text = intent.getStringExtra(EXTRA_DETAIL3)
        tvDetail4.text = intent.getStringExtra(EXTRA_DETAIL4)

        tvNameHeroes1.text = intent.getStringExtra(EXTRA_NAME_HEROES1)
        tvNameHeroes2.text = intent.getStringExtra(EXTRA_NAME_HEROES2)
        tvNameHeroes3.text = intent.getStringExtra(EXTRA_NAME_HEROES3)

        Glide.with(this)
            .load(intent.getStringExtra(EXTRA_PHOTO_HEROES1))
            .apply(RequestOptions())
            .into(imgvPhotoHeroes1)
        Glide.with(this)
            .load(intent.getStringExtra(EXTRA_PHOTO_HEROES2))
            .apply(RequestOptions())
            .into(imgvPhotoHeroes2)
        Glide.with(this)
            .load(intent.getStringExtra(EXTRA_PHOTO_HEROES3))
            .apply(RequestOptions())
            .into(imgvPhotoHeroes3)
    }

    companion object {
        const val EXTRA_NAME = "extra_name"
        const val EXTRA_DETAIL = "extra_detail"
        const val EXTRA_PHOTO = "extra_photo"
        const val EXTRA_DETAIL1 = "extra_detail1"
        const val EXTRA_DETAIL2 = "extra_detail2"
        const val EXTRA_DETAIL3 = "extra_detail3"
        const val EXTRA_DETAIL4 = "extra_detail4"
        const val EXTRA_NAME_HEROES1 = "extra_name_heroes1"
        const val EXTRA_NAME_HEROES2 = "extra_name_heroes2"
        const val EXTRA_NAME_HEROES3 = "extra_name_heroes3"
        const val EXTRA_PHOTO_HEROES1 = "extra_photo_heroes1"
        const val EXTRA_PHOTO_HEROES2 = "extra_photo_heroes2"
        const val EXTRA_PHOTO_HEROES3 = "extra_photo_heroes3"
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
