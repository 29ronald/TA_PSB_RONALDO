package id.rafeyosa.dicoding.fategrandorder

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions

class ListServantAdapter(private val listServant: ArrayList<ServantModel>) : RecyclerView.Adapter<ListServantAdapter.ListViewHolder>() {
    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ListViewHolder {
        val view: View = LayoutInflater.from(viewGroup.context).inflate(R.layout.servant_list_item, viewGroup,false )
        return ListViewHolder(view)
    }

    override fun getItemCount(): Int {
        return listServant.size
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val servant = listServant[position]
        // Glide.with(this).load("http://a.com").into(imageView)
        Glide.with(holder.itemView.context)
            .load(servant.logoServant)
            .apply(RequestOptions().override(55, 55))
            .into(holder.imgLogo)

        holder.tvName.text = servant.nameServant
        holder.tvDetail.text  = servant.detailServant

        val mContext = holder.itemView.context

        holder.itemView.setOnClickListener {
            val moveDetail = Intent(mContext, DetailActivity::class.java)
            moveDetail.putExtra(DetailActivity.EXTRA_NAME, servant.nameServant)
            moveDetail.putExtra(DetailActivity.EXTRA_DETAIL, servant.detailServant)
            moveDetail.putExtra(DetailActivity.EXTRA_PHOTO, servant.logoServant)
            moveDetail.putExtra(DetailActivity.EXTRA_DETAIL1, servant.detail1)
            moveDetail.putExtra(DetailActivity.EXTRA_DETAIL2, servant.detail2)
            moveDetail.putExtra(DetailActivity.EXTRA_DETAIL3, servant.detail3)
            moveDetail.putExtra(DetailActivity.EXTRA_DETAIL4, servant.detail4)
            moveDetail.putExtra(DetailActivity.EXTRA_NAME_HEROES1, servant.nameHeroes1)
            moveDetail.putExtra(DetailActivity.EXTRA_NAME_HEROES2, servant.nameHeroes2)
            moveDetail.putExtra(DetailActivity.EXTRA_NAME_HEROES3, servant.nameHeroes3)
            moveDetail.putExtra(DetailActivity.EXTRA_PHOTO_HEROES1, servant.photoHeroes1)
            moveDetail.putExtra(DetailActivity.EXTRA_PHOTO_HEROES2, servant.photoHeroes2)
            moveDetail.putExtra(DetailActivity.EXTRA_PHOTO_HEROES3, servant.photoHeroes3)
            mContext.startActivity(moveDetail)
        }
    }

    inner class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var tvName: TextView = itemView.findViewById(R.id.tv_servant_name)
        var tvDetail: TextView = itemView.findViewById(R.id.tv_servant_detail)
        var imgLogo: ImageView = itemView.findViewById(R.id.imgv_servant_logo)
    }
}