package id.rafeyosa.dicoding.fategrandorder

object ServantData {
    private val data1 = ServantModel(
        "Saber",
        "Knight of the Sword and Heroic Spirit of the Sword. A jack-of-all-trades warrior. Agile and powerful in close quarters. Extremely adept at swordsmanship.",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/b/b4/Class-Saber-Gold.png/revision/latest?cb=20190129130858",
        "Sabers have a base damage multiplier of 1.0x.",
        "Sabers have a base star generation rate of 10%.",
        "Sabers have a base star absorption of 100.",
        "Sabers have a base death rate of 35%.",
        "Artoria Pendragon",
        "Nero Claudius",
        "Gawain",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/4/43/Artoria1.png/revision/latest?cb=20170206150711",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/7/71/Nero1.png/revision/latest?cb=20170206151617",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/5/53/Gawain1.png/revision/latest?cb=20160731053049"
    )
    private val data2 = ServantModel(
        "Archer",
        "Knight of the Bow and Heroic Spirit of the Bow. Excellent scouts that excel in possessing powerful Noble Phantasms. Masters of long ranged warfare.",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/9/90/Class-Archer-Gold.png/revision/latest?cb=20190129130706",
        "Archers have a base damage multiplier of 0.95x.",
        "Archers have a base star generation rate of 8%.",
        "Archers have a base star absorption of 150.",
        "Archers have a base death rate of 45%.",
        "Gilgamesh",
        "Arjuna",
        "James Moriarty",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/e/ee/Gilgamesh1.png/revision/latest?cb=20170207175012",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/8/82/Arjuna1.png/revision/latest?cb=20151230150758",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/c/cd/ArcherMoriartyStage1.png/revision/latest?cb=20171206153632"
    )
    private val data3 = ServantModel(
        "Lancer",
        "Knight of the Lance and Heroic Spirit of the Lance. Gifted with extreme agility and proficient in hit-and-run tactics as well as ranged melee weapons such as spears and lances.",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/7/79/Class-Lancer-Gold.png/revision/latest?cb=20190129130840",
        "Lancers have a base damage multiplier of 1.05x.",
        "Lancers have a base star generation rate of 12%.",
        "Lancers have a base star absorption of 90.",
        " Lancers have a base death rate of 40%.",
        "Cú Chulainn",
        "Diarmuid Ua Duibhne",
        "Nezha",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/3/31/Cuchulainn1.png/revision/latest?cb=20170207175728",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/6/69/Diarmuid1.png/revision/latest?cb=20151210053505",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/2/25/Portrait_Servant_193_1.png/revision/latest?cb=20171129142413"
    )
    private val data4 = ServantModel(
        "Rider",
        "Mounted Knight and Heroic Spirit of the Mount. Experts of the mount able to tame any beast, be it mythical or mechanical.",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/0/04/Class-Rider-Gold.png/revision/latest?cb=20190129130852",
        "Riders have a base damage multiplier of 1.0x.",
        "Riders have a base star generation rate of 9%.",
        "Riders have a base star absorption of 200.",
        "Riders have a base death rate of 50%.",
        "Medusa",
        "Francis Drake",
        "Iskandar",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/9/9b/Medusa1.png/revision/latest?cb=20170208141542",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/5/57/Drake1.png/revision/latest?cb=20151105191741",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/7/72/Iskandar1.png/revision/latest?cb=20170203174201"
    )
    private val data5 = ServantModel(
        "Caster",
        "Magus and Heroic Spirit of Spells and Sorcery. Adept in magecraft, being one of the few able to use sorceries of the highest caliber.",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/8/89/Class-Caster-Gold.png/revision/latest?cb=20190129130807",
        "Casters have a base damage multiplier of 0.9x.",
        "Casters have a base star generation rate of 11%.",
        "Casters have a base star absorption of 50.",
        "Casters have a base death rate of 60%.",
        "Medea",
        "Gilles de Rais",
        "Tamamo no Mae",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/7/7b/Medea1.png/revision/latest?cb=20170208150547",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/5/54/DeRais1.png/revision/latest?cb=20170208150741",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/7/72/Tamamocaster.png/revision/latest?cb=20151021214450"
    )
    private val data6 = ServantModel(
        "Assassin",
        "Silent Killer and Heroic Spirit of Assassinations. Extremely skilled at covert, stealthy, and silent operations.",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/7/7b/Class-Assassin-Gold.png/revision/latest?cb=20190129130718",
        "Assassins have a base damage multiplier of 0.9x.",
        "Assassins have a base star generation rate of 25%.",
        " Assassins have a base star absorption of 100.",
        "Assassins have a base death rate of 55%.",
        "Hassan of the Cursed Arm",
        "Hassan of the Hundred Faces",
        "Hassan of the Serenity",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/b/b7/Fappynew1.png/revision/latest?cb=20180406084005",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/c/c6/HundredHassan1.png/revision/latest?cb=20170203175359",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/b/ba/Hofserenity1.png/revision/latest?cb=20160725145652"
    )
    private val data7 = ServantModel(
        "Berserker",
        "Mad Warrior and Heroic Spirit of Berserker Rage. Crazed warriors that have lost almost all traces of their sanity in exchange for great power.",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/5/59/Class-Berserker-Gold.png/revision/latest?cb=20190129130739",
        "Berserkers have a base damage multiplier of 1.1x.",
        "Berserkers have a base star generation rate of 5%.",
        "Berserkers have a base star absorption of 10.",
        "Berserkers have a base death rate of 65%.",
        "Heracles",
        "Lancelot",
        "Frankenstein",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/f/f2/Herc1.png/revision/latest?cb=20170208165217",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/2/2c/Lancelot1.png/revision/latest?cb=20170208165850",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/3/32/Frankenstein1.png/revision/latest?cb=20151228213043"
    )
    private val data8 = ServantModel(
        "Ruler",
        "Standard-Bearer who Correctly Guides the Holy Grail War. Virtuous warriors summoned by the Holy Grail itself, tasked with governing the rituals of the Grail Wars.",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/b/ba/Class-Ruler-Gold.png/revision/latest?cb=20190129131240",
        "Rulers have a base damage multiplier of 1.1x.",
        "Rulers have a base star generation rate of 10%.",
        "Rulers have a base star absorption of 100.",
        "Rulers have a base death rate of 35%.",
        "Jeanne d'Arc",
        "Amakusa Shirō",
        "Sherlock Holmes",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/5/56/Jeanne1.png/revision/latest?cb=20170208180646",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/5/5e/Ashirou1.png/revision/latest?cb=20160309054321",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/b/b1/Holmes1.png/revision/latest?cb=20180228115820"
    )
    private val data9 = ServantModel(
        "Avenger",
        "Vigilante and Heroic Spirit of Vengeance. Vindictive warriors that bear great hatred in the past, the embodiment of hatred itself. The dark side of the Holy Grail, which is the contents in the cup.",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/1/13/Class-Avenger-Gold.png/revision/latest?cb=20190129130729",
        "Avengers have a base damage multiplier of 1.1x.",
        "Avengers have a base star generation rate of 6%.",
        "Avengers have a base star absorption of 30.",
        "Avengers have a base death rate of 10%.",
        "Angra Mainyu",
        "Gorgon",
        "Demon King Nobunaga",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/a/aa/Angra1.png/revision/latest?cb=20161126152050",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/f/f7/Gorgon1.png/revision/latest?cb=20171206160919",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/5/58/Demon_King_Nobunaga1.png/revision/latest?cb=20190704124754"
    )
    private val data10 = ServantModel(
        "Alter Ego",
        "Alternate aspects and personalities split from their originals. Instead of being proper Heroic Spirits, they're personifications of emotions, wishes and various aspects that belong to others.",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/9/99/Class-Alterego-Gold.png/revision/latest?cb=20190129130649",
        "Alter Egos have a base damage multiplier of 1.0x.",
        "Alter Egos have a base star generation rate of 10%.",
        "Alter Egos have a base star absorption of 100.",
        "Alter Egos have a base death rate of 50%.",
        "Meltlilith",
        "Passionlip",
        "Kingprotea",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/9/9d/Meltlilithfirstascension.png/revision/latest?cb=20180227175605",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/5/5d/Passionlip1.png/revision/latest?cb=20180227175800",
        "https://vignette.wikia.nocookie.net/fategrandorder/images/a/a0/KingproteaStage1.png/revision/latest?cb=20190227130024 "
    )

    private val servantList = arrayOf(data1, data2, data3, data4, data5, data6, data7, data8, data9, data10)

    val listData: ArrayList<ServantModel>
        get() {
            val list = ArrayList<ServantModel>()
            for (isData in servantList) {
                val servantModel = ServantModel()
                servantModel.nameServant = isData.nameServant
                servantModel.detailServant = isData.detailServant
                servantModel.logoServant = isData.logoServant
                servantModel.detail1 = isData.detail1
                servantModel.detail2 = isData.detail2
                servantModel.detail3 = isData.detail3
                servantModel.detail4 = isData.detail4
                servantModel.nameHeroes1 = isData.nameHeroes1
                servantModel.nameHeroes2 = isData.nameHeroes2
                servantModel.nameHeroes3 = isData.nameHeroes3
                servantModel.photoHeroes1 = isData.photoHeroes1
                servantModel.photoHeroes2 = isData.photoHeroes2
                servantModel.photoHeroes3 = isData.photoHeroes3
                
                list.add(servantModel)
            }
            return list
        }
}