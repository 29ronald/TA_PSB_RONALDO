package id.rafeyosa.dicoding.fategrandorder

data class ServantModel(
    var nameServant: String = "",
    var detailServant: String = "",
    var logoServant: String = "",
    var detail1: String = "",
    var detail2: String = "",
    var detail3: String = "",
    var detail4: String = "",
    var nameHeroes1: String = "",
    var nameHeroes2: String = "",
    var nameHeroes3: String = "",
    var photoHeroes1: String = "",
    var photoHeroes2: String = "",
    var photoHeroes3: String = ""
)